class HelloWorld {
	static void Main() {
		System.Console.WriteLine("Hello World");
	}
}