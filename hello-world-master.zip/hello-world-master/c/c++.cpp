#include <iostream> // include API

using namespace std;

int main() // the main code portion of a C++ program
{
   cout << "Hello World" << endl;  //print Hello World on the screen 
   return 0; // conventional
}
