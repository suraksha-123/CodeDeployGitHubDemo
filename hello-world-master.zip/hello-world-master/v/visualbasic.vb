Module HelloWorld
    Sub Main()
        MsgBox("Hello world!")
    End Sub
End Module