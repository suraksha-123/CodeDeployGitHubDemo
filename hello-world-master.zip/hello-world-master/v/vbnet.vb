Module HelloWorld
    Sub Main()
        System.Console.WriteLine("Hello World")
    End Sub
End Module