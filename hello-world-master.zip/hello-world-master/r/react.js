//simple react component that renders "Hello World" as an H1 tag into the body 

React.render(<h1>Hello World</h1>, document.body);