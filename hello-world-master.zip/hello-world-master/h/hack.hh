<?hh 
echo 'Hello World';
